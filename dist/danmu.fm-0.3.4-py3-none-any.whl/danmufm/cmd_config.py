# -*- coding: utf-8 -*-
config = {
    "video_quality": None,
    "danmu_mode": None,
    "video_stored_path": None,
    "verbose": None,
    "zhubo_room_url": None,  # 命令行获取的配置
}

room_status = {
    "sd_rmtp_url": None,
    "hd_rmtp_url": None,
    "spd_rmtp_url": None,
    "id": None,
    "name": None,
    "gg_show": None,
    "owner_uid": None,
    "owner_name": None,
    "room_url": None,
    "near_show_time": None,
    "username": None,
    "tags": None,
    "live_stat": None,
    "fans_count": None,
    "weight": None,
    "is_finished": False  # 当标记为 True的时候,这个时候所有的
}
