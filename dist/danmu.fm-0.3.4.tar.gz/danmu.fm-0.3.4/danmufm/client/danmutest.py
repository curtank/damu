from .douyu_client import DouyuClient
url="156277"
fun=DouyuClient(url).start
